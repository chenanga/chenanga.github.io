---
title: 个人简历
date: 2022-07-12 15:47:12
aside: false
---

 <center>
     <h1 style = "font-size: 50px">陈 昂</h1>
 </center>

<div class="btn-center">
	{% btn 'https://www.blogca.cn/resume/',18145158816,iconfont icon-dianhua,blue outline larger  %} 
    {% btn 'mailto:blogchen@qq.com',blogchen@qq.com,iconfont icon-Mail, blue outline larger %} 
    {% btn 'https://github.com/chenanga', Github,iconfont icon-github, blue outline larger %} 
    {% btn 'https://blog.csdn.net/weixin_42035347', CSDN,iconfont icon-csdn1, blue outline larger %}
</div>



 ## {%inlineImg https://img-bed-youpaiyun.blogca.cn/pic-blogca/butterfly/icons/info-circle-solid.svg  20px %} 个人信息 

- **男， 1998.10， 中共党员**

## {%inlineImg https://img-bed-youpaiyun.blogca.cn/pic-blogca/butterfly/icons/graduation-cap-solid.svg  20px %} 教育背景 

| **哈尔滨工程大学** | **人工智能** | **工学硕士** | **2020.09 – 2023.06 (TOP 10%)** |
| :----------------- | :----------: | :----------: | ------------------------------: |
| 西南民族大学       |    自动化    |   工学学士   |      2016.09 – 2020.06 (TOP 2%) |

## {%inlineImg https://img-bed-youpaiyun.blogca.cn/pic-blogca/butterfly/icons/tools-solid.svg  20px %} 专业技能

- 熟悉C++，熟练使用C++的封装继承多态、STL常用容器，C++11常用特性（智能指针）了解Python编程；
- 熟悉常见数据结构及算法（链表、栈、队列、二叉树、并查集等），熟练使用排序、贪心、动态规划等算法；
- 熟悉计算机网络，掌握HTTP/HTTPS、TCP/UDP、IP等常见协议，熟悉TCP流量控制、拥塞控制等手段；
- 掌握Linux系统编程，了解操作系统原理，了解系统调度、IPC、进程线程以及内存管理机制；
- 对Linux下I/O复用技术有深刻理解，能够利用Socket套接字进行网络编程，了解常见的事件处理模式；
- 熟悉使用MySQL，熟悉MySQL的索引、存储引擎、缓存、日志、锁机制和事务机制；

## {%inlineImg https://img-bed-youpaiyun.blogca.cn/pic-blogca/butterfly/icons/project-diagram-solid.svg  20px %} 项目经历

### **Linux下C++轻量级Web服务器** {% label 2021.09-2022.04 blue %}

- **概述**：基于非阻塞I/O和模拟Proactor事件处理模式的高并发服务器，支持解析GET、POST请求，能够响应静态资源的请求,同时支持20000+客户端连接，QPS最高10万+。

- **负责**：

  \- 使用线程池、非阻塞Socket、Epoll (LT/ET)和模拟Proactor实现的并发模型；

  \- 使用主从状态机解析HTTP请求报文，支持GET和POST请求，支持HTTP短/长连接；

  \- 基于排序链表实现的超时长连接清除，同步/异步的日志系统，可通过YAML文件进行配置；

  \- RAII机制数据库连接池实现Web端用户注册、登录功能，可以请求服务器图片和视频文件；

  \- 经过Webbench的压力测试可以实现20000+的并发连接数据交换。

- **Github地址：**https://github.com/chenanga/MyWebServer   （已上传）

### **JSON解析器** {% label 2021.06-2021.09 blue %}

- **概述**：使用C语言实现一个简单的JSON解析器，，对JSON 六种数据类型的解析(null,boolean,number,string,array,object)

- **负责**：

  \- 完成六种数据类型解析程序的编写，以及使用TDD 方式进行测试程序的编写；

  \- 对string、array、object 类型使用union 节省内存空间，使用堆栈优化处理过程，同时使用内存泄漏检测工具对程序进行检测以保证程序的正确性；

  \- 选用动态数组来存储object 对象，同时对前面字符串解析进行重构，优化程序；

  \- 完善系统，添加对象键值查询功能，以及每个元素类型的比较、复制、移动等基本功能；

- **Github地址：** https://github.com/chenanga/MyJsonParser （待上传）





### **声呐综合处理系统**  {% label 2021.05-2022.03 blue %}

- **概述**：基于Python的前视和侧扫声呐二进制数据解析、数据可视化、声呐图像检测和拼接系统。

- **负责**：

  \- 项目负责人，项目整体结构设计、以及界面相关的开发和构建，用户交互模块设计；

  \- 多种格式的声呐二进制数据解析，图像预处理，使用Numba加速像素操作，大幅提升速度；

  \- 检测算法与可视化界面的联调，通过修改检测网络的接口，提升整体系统的检测速度；

  \- 使用PyInstaller将整个项目转换为可以在任意其他同系统电脑运行的可执行文件。





### **海洋目标智能感知国际挑战赛评分系统搭建**  {% label 2021.04-2022.09 blue %}

- **概述**：协助老师进行比赛评分系统的搭建，并且部署在服务器上，和前端联调，实现自动评分。

- **负责**：

  \- 评分系统Python脚本的编写，评分程序在服务器的部署；

  \- 通过改变评分策略，以及使用多线程处理，提高评分效率；

  \- 与华为工程师联调，部署在NAIE MASTER平台上。

  



### 畜牧云-高原民族牧区牦牛防疫及信息采集的云管理系统   {% label 2018.04-2019.05 blue %}

- **概述**：利用自主设计的图像采集处理系统和太阳能系统对牦牛的信息进行管理，使传统行业更智能化降低养殖成本，提高工作效率。

- **负责**：

  \- 项目负责人。利用图像处理算法对牦牛进行信息的采集，通过图像去噪、二值化处理、关键点检测、获取其肩高体长，同时通过串口获取该牦牛的身份序列号(RFID序列号)，并通过时间戳信息进行匹配，写入数据库。

  





## {%inlineImg https://img-bed-youpaiyun.blogca.cn/pic-blogca/butterfly/icons/9.png  20px %} 获奖情况

- 2021年09月， 研究生一等奖学金
- 2020年09月， 研究生二等奖学金
- 2020年06月， 四川省综合素质A级证书
- 2020年03月， 四川省优秀毕业生
- 2019年12月， 四川省互联网+省级铜奖
- 2019年06月， 主持国家级大创项目
- 2018年05月， 四川省计算机设计大赛三等奖
- 其他奖项若干，国家励志奖学金、三好学生、优秀学生、优秀学生干部等

## {%inlineImg https://img-bed-youpaiyun.blogca.cn/pic-blogca/butterfly/icons/0.png  20px %} 自我评价

- 热爱编程，对新鲜事物保持热情，做事情喜欢追求完美。可根据日常需求做出适用于某些场景的定制化脚本。
- 有探索精神，使用过对象存储，云服务器，CDN等云服务产品，通过企业微信和云服务器的联动实现在微信端设置提醒事项。
- 撰写过技术博客，在CSDN有2000+粉丝。
- 有良好的团队合作和沟通能力，曾担任过党支部书记、嵌入式协会部长。



<br>

> 感谢抽空阅读





